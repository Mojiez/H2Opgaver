﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBanker.Interfaces
{
    //Interface used to make cards work in other countries
    interface IInternationalTrade
    {
        void BuyInternational();
    }
}
