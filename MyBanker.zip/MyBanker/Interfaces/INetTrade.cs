﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBanker.Interfaces
{
    //This interface is used to make card work online
    interface INetTrade
    {
        void BuyOnline();
    }
}
